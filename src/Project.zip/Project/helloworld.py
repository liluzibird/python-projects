def hello():
	print("Hello ")

def world():
	print("World")
